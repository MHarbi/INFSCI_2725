library(igraph)
library(proxy)

A1 <- matrix(c(0,1,0,0,0,
               0,0,0,1,0,
               1,1,0,0,0,
               1,0,0,0,1,
               1,0,0,0,0),
            nrow=5, ncol=5, byrow=TRUE)

A2 <- matrix(c(0,1,1,0,
               0,0,1,1,
               1,0,1,0,
               0,0,1,0),
            nrow=4, ncol=4, byrow=TRUE)

G1 <- graph.adjacency(A1, mode=c("directed"), weighted=NULL)
G2 <- graph.adjacency(A2, mode=c("directed"), weighted=NULL)

k <- 1

for(i in 1:5){
  A[i,] <- A[i,] / length(A[i, A[i, ]==1])
}

HITS<-function(g,k)
{ 
  adj <- get.adjacency(g, sparse=F) 
  nodes <- dim(adj)[1] 
  auth <- c(rep(1, nodes)) 
  hub <- c(rep(1, nodes)) 
  for(i in 1:k){ 
    t_adj <- t(adj) 
    auth <- t_adj%*%hub 
    hub <- adj%*%auth
    
    #auth <- auth/sum(auth)
    #hub <- hub/sum(hub)
    sum_sq_auth <- sum(auth*auth) 
    sum_sq_hub <- sum(hub*hub) 
    auth <- auth/sqrt(sum_sq_auth) 
    hub <- hub/sqrt(sum_sq_hub)
  } 
  
  result <- c(auth, hub)
  return(auth) 
}

HITS1<-function(g,k)
{ 
  adj <- get.adjacency(g, sparse=F) 
  nodes <- dim(adj)[1] 
  auth <- c(rep(1, nodes)) 
  hub <- c(rep(1, nodes)) 
  for(i in 1:k){ 
    t_adj <- t(adj) 
    auth <- t_adj%*%adj%*%auth 
    hub <- adj%*%t_adj%*%hub
  } 
  
  result <- c(auth, hub)   
  return(result) 
}

for(i in 1:20){
  cat(t(round(HITS(G2,i), 4)))
  cat("\n")
}
