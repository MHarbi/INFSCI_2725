library(readr)
# load HouseVotes84 dataset
#data("HouseVotes84")
HouseVotes84 <- read_delim("../house-votes-84.txt", delim = "\t")

# replace 'w' value with NA in all columns
for (i in 2:ncol(HouseVotes84)) {
  if(length(HouseVotes84[HouseVotes84[,i]=='w', i]) > 0) {
    HouseVotes84[which(HouseVotes84[,i] == 'w', arr.ind = T), i] = NA
  }
}
  
# Functions needed for imputation
# function to return number of NAs by vote and class (democrat or republican)
na_by_col_class <- function (col, cls){
  return(sum(is.na(HouseVotes84[,col]) & HouseVotes84$Party==cls))
}
# function to compute the conditional probability that a member of a party will cast a ‘yes’ vote for
# a particular issue. The probability is based on all members of the party who 
# actually cast a vote on the issue (ignores NAs).
p_y_col_class <- function(col, cls){
  sum_y <- sum(HouseVotes84[,col]=='y' & HouseVotes84$Party==cls, na.rm = TRUE)
  sum_n <- sum(HouseVotes84[,col]=='n' & HouseVotes84$Party==cls, na.rm = TRUE)
  return(sum_y/(sum_y+sum_n))
}

HV <- HouseVotes84
#impute missing values.
for (i in 2:ncol(HouseVotes84)) {
  if(sum(is.na(HouseVotes84[,i]) > 0)) {
    
    c1 <- which(is.na(HouseVotes84[,i]) & HouseVotes84$Party=='democrat', arr.ind = TRUE)
    c2 <- which(is.na(HouseVotes84[,i]) & HouseVotes84$Party=='republican', arr.ind = TRUE)
    HouseVotes84[c1,i] <-
      ifelse(runif(na_by_col_class(i, 'democrat')) < p_y_col_class(i, 'democrat'), 'y', 'n')
    HouseVotes84[c2,i] <-
      ifelse(runif(na_by_col_class(i, 'republican')) < p_y_col_class(i, 'republican'), 'y', 'n')}
}

write_delim(HouseVotes84, "../house-votes-84-no-na.txt", delim = "\t")
write_csv(HouseVotes84, "../house-votes-84-no-na.csv")
